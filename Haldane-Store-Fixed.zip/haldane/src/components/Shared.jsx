import { ph } from '../data/ph.js'
import { categoryImages } from '../data/products.js'
import { useEffect, useRef, useState } from 'react'
import { createPortal } from 'react-dom'
import { Link } from 'react-router-dom'
import { Heart, Star, Minus, Plus, ChevronRight, ShoppingBag, SearchX, X, Eye } from 'lucide-react'
import { useStore } from '../context/StoreContext.jsx'
export const money = n => '₹' + n.toLocaleString('en-IN', { minimumFractionDigits: Number.isInteger(n) ? 0 : 2, maximumFractionDigits: 2 })
const BASE = import.meta.env?.BASE_URL ?? '/'
export function SafeImg({ src, alt, ...r }) {
  const [failed, setFailed] = useState(0)
  useEffect(() => setFailed(0), [src])
  const m = String(src).match(/images\/(?:products\/(\d+)-(\d)|categories\/(\w+)|hero)\.jpg$/)
  const fallback = m && (m[1] ? ph(`haldane${m[1]}x${m[2] - 1}`) : m[3] ? ph(`haldanecat${m[3]}`) : ph('haldanehero'))
  const cur = failed === 0 ? src : failed === 1 ? fallback : null
  if (!cur) return <div className="img-fallback" role="img" aria-label={alt}>{alt?.[0]}</div>
  return <img src={cur} alt={alt} loading="lazy" onError={() => setFailed(f => f + 1)} {...r} />
}
export const PriceDisplay = ({ price, originalPrice }) => <span className="price">{money(price)}{originalPrice && <s>{money(originalPrice)}</s>}</span>
export const discountPct = p => p.originalPrice ? Math.round((1 - p.price / p.originalPrice) * 100) : 0
export const RatingStars = ({ rating, reviews }) => <span className="stars" aria-label={`${rating} out of 5 from ${reviews} reviews`}>
  {[1, 2, 3, 4, 5].map(n => <Star key={n} size={14} className={n <= Math.round(rating) ? 'on' : ''} />)}{reviews != null && <small>({reviews})</small>}</span>
export function WishlistButton({ product }) {
  const { wishlist, toggleWish } = useStore(); const on = wishlist.includes(product.id)
  return <button className={'wish' + (on ? ' on' : '')} aria-pressed={on} aria-label={on ? `Remove ${product.name} from wishlist` : `Save ${product.name} to wishlist`} onClick={() => toggleWish(product)}><Heart size={18} /></button>
}
export function QuantitySelector({ value, onChange, min = 1, max = 10 }) {
  return <div className="qty" role="group" aria-label="Quantity">
    <button aria-label="Decrease quantity" disabled={value <= min} onClick={() => onChange(value - 1)}><Minus size={14} /></button>
    <input aria-label="Quantity" inputMode="numeric" value={value} onChange={e => onChange(Math.max(min, Math.min(max, parseInt(e.target.value) || min)))} />
    <button aria-label="Increase quantity" disabled={value >= max} onClick={() => onChange(value + 1)}><Plus size={14} /></button></div>
}
export const Breadcrumbs = ({ items }) => <nav aria-label="Breadcrumb" className="crumbs"><ol>{items.map((it, i) => <li key={i}>{it.to ? <Link to={it.to}>{it.label}</Link> : <span aria-current="page">{it.label}</span>}{i < items.length - 1 && <ChevronRight size={14} />}</li>)}</ol></nav>
export function QuickView({ p, onClose }) {
  const { addToCart } = useStore(); const [v, setV] = useState(p.variants[0]); const ref = useRef()
  useEffect(() => { ref.current?.focus(); const k = e => e.key === 'Escape' && onClose(); window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k) }, [onClose])
  return createPortal(<div className="qv-back" onClick={onClose}><div className="qv" role="dialog" aria-modal="true" aria-label={`Quick view: ${p.name}`} onClick={e => e.stopPropagation()}>
    <button ref={ref} className="icon-btn qv-x" aria-label="Close quick view" onClick={onClose}><X /></button><SafeImg src={p.image} alt={p.name} />
    <div className="qv-info"><h2>{p.name}</h2><RatingStars rating={p.rating} reviews={p.reviews} /><PriceDisplay price={p.price} originalPrice={p.originalPrice} /><p>{p.description}</p>
      <div>{p.variants.map(x => <button key={x} className={'chip' + (x === v ? ' on' : '')} aria-pressed={x === v} onClick={() => setV(x)}>{x}</button>)}</div>
      <button className="btn" disabled={p.stock === 0} onClick={() => { addToCart(p, v); onClose() }}>{p.stock === 0 ? 'Out of stock' : 'Add to cart'}</button>
      <Link className="btn ghost" to={`/product/${p.id}`} onClick={onClose}>View full details</Link></div></div></div>, document.body)
}
export function ProductCard({ product: p }) {
  const { addToCart } = useStore(), [qv, setQv] = useState(false); const d = discountPct(p)
  return <article className="card"><div className="card-img"><Link to={`/product/${p.id}`}><SafeImg src={p.image} alt={p.name} /></Link>
    {d > 0 && <span className="badge">−{d}%</span>}{p.stock === 0 && <span className="badge dark">Sold out</span>}
    <WishlistButton product={p} /><button className="wish qv-btn" aria-label={`Quick view ${p.name}`} onClick={() => setQv(true)}><Eye size={18} /></button>
    <button className="quick" disabled={p.stock === 0} onClick={() => addToCart(p, p.variants[0])}><ShoppingBag size={16} /> Quick add</button></div>
    <div className="card-body"><h3><Link to={`/product/${p.id}`}>{p.name}</Link></h3><RatingStars rating={p.rating} reviews={p.reviews} /><PriceDisplay price={p.price} originalPrice={p.originalPrice} /></div>{qv && <QuickView p={p} onClose={() => setQv(false)} />}</article>
}
export const ProductGrid = ({ items }) => <div className="grid">{items.map(p => <ProductCard key={p.id} product={p} />)}</div>
export const CategoryCard = ({ c }) => <Link to={`/shop?category=${c.id}`} className="cat"><SafeImg src={categoryImages[c.id]} alt={c.name} /><span><strong>{c.name}</strong><small>{c.blurb}</small></span></Link>
export const EmptyState = ({ icon: I = SearchX, title, text, children }) => <div className="empty"><I size={40} /><h2>{title}</h2><p>{text}</p>{children}</div>
