import { useState } from 'react'
import { Link, NavLink, useNavigate } from 'react-router-dom'
import { Search, Heart, ShoppingBag, Menu, X, Instagram, Twitter, Youtube, Check, LogOut } from 'lucide-react'
import { useAuth } from '../context/AuthContext.jsx'
import { money } from './Shared.jsx'
import { categories, products } from '../data/products.js'
import { useStore } from '../context/StoreContext.jsx'
export const Logo = () => <Link to="/" className="logo" aria-label="Haldane home"><span className="logo-mark">H</span>aldane</Link>
export const AnnouncementBar = () => <div className="announce">Free shipping over ₹999 · Use code WELCOME10 for 10% off</div>
export function SearchBar({ onDone }) {
  const [q, setQ] = useState(''), [open, setOpen] = useState(false); const nav = useNavigate(); const hits = q.trim().length > 1 ? products.filter(p => p.name.toLowerCase().includes(q.trim().toLowerCase())).slice(0, 5) : []
  const go = (e) => { e.preventDefault(); nav(`/shop?q=${encodeURIComponent(q.trim())}`); onDone?.() }
  return <div className="sb-wrap"><form className="searchbar" role="search" onSubmit={go}><label className="sr" htmlFor="gs">Search products</label>
    <input id="gs" value={q} autoComplete="off" onChange={e => { setQ(e.target.value); setOpen(true) }} onBlur={() => setTimeout(() => setOpen(false), 150)} placeholder="Search lamps, pens, totes" /><button aria-label="Search"><Search size={18} /></button></form>{open && hits.length > 0 && <ul className="suggest" aria-label="Suggestions">{hits.map(p => <li key={p.id}><Link to={`/product/${p.id}`} onClick={() => { setQ(""); setOpen(false); onDone?.() }}><span>{p.name}</span><b>{money(p.price)}</b></Link></li>)}</ul>}</div>
}
export function Navbar() {
  const [open, setOpen] = useState(false); const { cartCount, wishlist, setDrawer } = useStore(), { user, logout } = useAuth()
  return <header className="nav"><div className="wrap nav-in">
    <button className="icon-btn menu-btn" aria-label={open ? 'Close menu' : 'Open menu'} aria-expanded={open} onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</button>
    <Logo />
    <nav className={'links' + (open ? ' open' : '')} aria-label="Main">
      <NavLink to="/shop" end onClick={() => setOpen(false)}>All products</NavLink>
      {categories.map(c => <Link key={c.id} to={`/shop?category=${c.id}`} onClick={() => setOpen(false)}>{c.name}</Link>)}
      <div className="mobile-search"><SearchBar onDone={() => setOpen(false)} /></div>
    </nav>
    <div className="nav-tools"><div className="desk-search"><SearchBar /></div>
      <Link className="icon-btn" to="/shop?wishlist=1" aria-label={`Wishlist, ${wishlist.length} items`}><Heart />{wishlist.length > 0 && <b className="count">{wishlist.length}</b>}</Link>
      <button className="icon-btn" onClick={() => setDrawer(true)} aria-label={`Cart, ${cartCount} items`}><ShoppingBag />{cartCount > 0 && <b className="count">{cartCount}</b>}</button><span className="hello">Hi, {user?.name.split(" ")[0]}</span><button className="icon-btn" onClick={logout} aria-label="Log out"><LogOut /></button></div>
  </div></header>
}
export function Footer() {
  return <footer className="footer"><div className="wrap foot-grid">
    <div><Logo /><p>Considered tools for the desk you actually use. Frontend demo store — no real orders.</p>
      <div className="social">{[[Instagram, 'Instagram'], [Twitter, 'Twitter'], [Youtube, 'YouTube']].map(([I, n]) => <a key={n} href="https://example.com" target="_blank" rel="noreferrer" aria-label={n}><I size={18} /></a>)}</div></div>
    <div><h4>Shop</h4>{categories.map(c => <Link key={c.id} to={`/shop?category=${c.id}`}>{c.name}</Link>)}</div>
    <div><h4>Help</h4><Link to="/cart">Cart and checkout</Link><Link to="/shop">Free shipping over ₹999</Link></div>
    <div><h4>Account</h4><Link to="/shop?wishlist=1">Wishlist</Link><Link to="/cart">Your cart</Link></div>
  </div><div className="wrap copy">© 2026 Haldane. Demo project.</div></footer>
}
export function Toasts() {
  const { toasts } = useStore()
  return <div className="toasts" role="status" aria-live="polite">{toasts.map(t => <div key={t.id} className="toast"><Check size={16} />{t.msg}</div>)}</div>
}
