import { useEffect, useRef, useState } from 'react'
import { useLocation, useMatch } from 'react-router-dom'
import { MessageCircle, X, Minus, Maximize2, Send, RotateCcw } from 'lucide-react'
import ChatMessage from './ChatMessage.jsx'
import { sendChat } from '../../services/chatApi.js'
import '../../styles/chatbot.css'
const WELCOME = "Hi there! 👋 Welcome to Haldane Store. I'm your shopping assistant. I can help you find products, check product details, understand delivery and return policies, and answer your shopping questions. How can I help you today?"
const SUGGEST = ['Help me find a product', 'What are your delivery options?', 'What is your return policy?', 'Recommend products for me', 'How do I track my order?']
const fresh = () => [{ id: 0, role: 'assistant', text: WELCOME }]
export default function ChatWidget() {
  const [mode, setMode] = useState('closed'), [msgs, setMsgs] = useState(fresh), [input, setInput] = useState(''), [busy, setBusy] = useState(false), [seen, setSeen] = useState(false)
  const end = useRef(), field = useRef(), lock = useRef(false), pm = useMatch('/product/:id'), { pathname } = useLocation()
  useEffect(() => { end.current?.scrollIntoView({ block: 'end' }) }, [msgs, busy, mode])
  useEffect(() => { if (mode === 'open') { field.current?.focus(); setSeen(true) } }, [mode])
  const send = async text => {
    const message = text.trim(); if (!message || lock.current) return
    lock.current = true; setBusy(true)
    const history = msgs.filter(m => m.id).slice(-10).map(m => ({ role: m.role, content: m.text }))
    setMsgs(m => [...m, { id: Date.now(), role: 'user', text: message }]); setInput('')
    const lastIds = [...msgs].reverse().find(m => m.productIds?.length)?.productIds || []
    const r = await sendChat({ message, history, productId: pm?.params.id, lastIds })
    setMsgs(m => [...m, { id: Date.now() + 1, role: 'assistant', text: r.reply, productIds: r.productIds, actions: r.actions, note: r.note }])
    lock.current = false; setBusy(false)
  }
  const off = !!msgs[msgs.length - 1]?.note
  return <div className="chat-root">
    {mode !== 'closed' && <section className={'chat-win' + (mode === 'min' ? ' min' : '')} role="dialog" aria-label="Haldane Store Assistant" onKeyDown={e => e.key === 'Escape' && setMode('closed')}>
      <header className="chat-head"><div className="chat-av"><MessageCircle size={18} /></div><div className="grow"><strong>Haldane Store Assistant</strong><small><i className={'dot' + (off ? ' off' : '')} />{off ? 'Catalog-only mode' : 'Online'}</small></div>
        <button className="icon-btn" aria-label="Start a new conversation" onClick={() => setMsgs(fresh())}><RotateCcw size={16} /></button>
        <button className="icon-btn" aria-label={mode === 'min' ? 'Expand chat' : 'Minimize chat'} onClick={() => setMode(mode === 'min' ? 'open' : 'min')}>{mode === 'min' ? <Maximize2 size={16} /> : <Minus size={16} />}</button>
        <button className="icon-btn" aria-label="Close chat" onClick={() => setMode('closed')}><X size={18} /></button></header>
      {mode === 'open' && <><div className="chat-log" role="log" aria-live="polite" aria-label="Conversation">
        {msgs.map(m => <ChatMessage key={m.id} m={m} />)}
        {msgs.length === 1 && <div className="sugg">{SUGGEST.map(s => <button key={s} className="chip" onClick={() => send(s)}>{s}</button>)}</div>}
        {busy && <div className="typing" role="status" aria-label="Assistant is typing"><i /><i /><i /></div>}<div ref={end} /></div>
        <form className="chat-form" onSubmit={e => { e.preventDefault(); send(input) }}><label className="sr" htmlFor="chat-in">Message</label>
          <input id="chat-in" ref={field} value={input} maxLength={500} autoComplete="off" disabled={busy} onChange={e => setInput(e.target.value)} placeholder="Ask about products, delivery, returns…" />
          <button className="btn send" disabled={busy || !input.trim()} aria-label="Send message"><Send size={18} /></button></form></>}
    </section>}
    {mode === 'closed' && <button className={'chat-fab' + (seen ? '' : ' attn') + (pathname === '/cart' ? ' compact' : '')} aria-label="Open chat assistant" onClick={() => setMode('open')}><MessageCircle size={26} />{!seen && <b className="fab-dot" />}</button>}
  </div>
}
