import { useState } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { ShoppingBag } from 'lucide-react'
import { products } from '../../data/products.js'
import { useStore } from '../../context/StoreContext.jsx'
import { SafeImg, PriceDisplay } from '../Shared.jsx'
export function ProductRecommendation({ p }) {
  const { addToCart } = useStore(), [v, setV] = useState(p.variants[0])
  return <div className="pcard"><Link to={`/product/${p.id}`}><SafeImg src={p.image} alt={p.name} /></Link>
    <div><h4><Link to={`/product/${p.id}`}>{p.name}</Link></h4><PriceDisplay price={p.price} originalPrice={p.originalPrice} />
      {p.variants.length > 1 && <select aria-label={`Option for ${p.name}`} value={v} onChange={e => setV(e.target.value)}>{p.variants.map(x => <option key={x}>{x}</option>)}</select>}
      <div className="row"><button className="btn mini" disabled={p.stock === 0} onClick={() => addToCart(p, v)}><ShoppingBag size={14} /> {p.stock === 0 ? 'Sold out' : 'Add'}</button><Link className="btn mini ghost" to={`/product/${p.id}`}>Details</Link></div></div></div>
}
export default function ChatMessage({ m }) {
  const { setDrawer } = useStore(), nav = useNavigate()
  const items = (m.productIds || []).map(id => products.find(p => p.id === id)).filter(Boolean)
  return <div className={'msg ' + m.role}><div className="bubble">{m.text}</div>
    {m.note && <p className="chat-note" role="status">{m.note}</p>}
    {items.map(p => <ProductRecommendation key={p.id} p={p} />)}
    {m.actions?.includes('open_cart') && <button className="chip" onClick={() => setDrawer(true)}>Open cart</button>}
    {m.actions?.includes('open_shop') && <button className="chip" onClick={() => nav('/shop')}>Open shop</button>}</div>
}
