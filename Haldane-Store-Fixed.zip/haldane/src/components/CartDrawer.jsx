import { useEffect, useRef } from 'react'
import { Link } from 'react-router-dom'
import { X, Trash2, Truck } from 'lucide-react'
import { products, SHIPPING } from '../data/products.js'
import { useStore } from '../context/StoreContext.jsx'
import { SafeImg, QuantitySelector, money } from './Shared.jsx'
export default function CartDrawer() {
  const { cart, drawer, setDrawer, setQty, removeItem } = useStore(); const ref = useRef()
  useEffect(() => { if (!drawer) return; ref.current?.focus(); const k = e => e.key === 'Escape' && setDrawer(false); window.addEventListener('keydown', k); return () => window.removeEventListener('keydown', k) }, [drawer, setDrawer])
  const lines = cart.map(i => ({ ...i, p: products.find(p => p.id === i.id) })).filter(l => l.p)
  const sub = lines.reduce((s, l) => s + l.p.price * l.qty, 0), left = Math.max(0, SHIPPING.freeOver - sub)
  return <><div className={'dscrim' + (drawer ? ' show' : '')} onClick={() => setDrawer(false)} />
    <aside className={'cdrawer' + (drawer ? ' open' : '')} role="dialog" aria-modal="true" aria-label="Shopping cart">
      <div className="cd-head"><h2>Your cart</h2><button ref={ref} className="icon-btn" aria-label="Close cart" onClick={() => setDrawer(false)}><X /></button></div>
      <div className="ship-bar"><Truck size={14} /> {left ? `${money(left)} away from free shipping` : 'You get free shipping'}<div><i style={{ width: `${Math.min(100, sub / SHIPPING.freeOver * 100)}%` }} /></div></div>
      {lines.length ? <ul className="cd-body">{lines.map(l => <li key={l.key}><SafeImg src={l.p.image} alt={l.p.name} /><div><strong>{l.p.name}</strong><p>{l.variant} · {money(l.p.price)}</p>
        <div className="row"><QuantitySelector value={l.qty} max={Math.max(1, Math.min(10, l.p.stock))} onChange={n => setQty(l.key, n, Math.min(10, l.p.stock))} /><button className="link-btn" onClick={() => removeItem(l.key)}><Trash2 size={14} /> Remove</button></div></div></li>)}</ul>
        : <div className="cd-body empty"><p>Your cart is empty.</p><Link className="btn" to="/shop" onClick={() => setDrawer(false)}>Browse products</Link></div>}
      {lines.length > 0 && <div className="cd-foot"><div className="row" style={{ justifyContent: 'space-between' }}><span>Subtotal</span><strong>{money(sub)}</strong></div><Link className="btn big" to="/cart" onClick={() => setDrawer(false)}>Review and checkout</Link></div>}
    </aside></>
}
