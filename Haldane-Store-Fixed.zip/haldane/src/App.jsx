import { useEffect } from 'react'
import { Routes, Route, useLocation } from 'react-router-dom'
import { AnnouncementBar, Navbar, Footer, Toasts } from './components/Layout.jsx'
import CartDrawer from './components/CartDrawer.jsx'
import Login from './pages/Login.jsx'
import { useAuth } from './context/AuthContext.jsx'
import ChatWidget from './components/chatbot/ChatWidget.jsx'
import Home from './pages/Home.jsx'
import Shop from './pages/Shop.jsx'
import ProductDetails from './pages/ProductDetails.jsx'
import CartCheckout from './pages/CartCheckout.jsx'
export default function App() {
  const { pathname } = useLocation(), { user } = useAuth()
  useEffect(() => window.scrollTo(0, 0), [pathname])
  if (!user) return <Login />
  return (<>
    <AnnouncementBar /><Navbar />
    <main id="main"><Routes>
      <Route path="/" element={<Home />} /><Route path="/shop" element={<Shop />} />
      <Route path="/product/:id" element={<ProductDetails />} /><Route path="/cart" element={<CartCheckout />} />
      <Route path="*" element={<Home />} />
    </Routes></main>
    <Footer /><Toasts /><CartDrawer /><ChatWidget />
  </>)
}
