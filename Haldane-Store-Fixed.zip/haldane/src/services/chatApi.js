import { products, categories } from '../data/products.js'
import { policies as P } from '../data/storePolicies.js'
const API = import.meta.env.VITE_API_URL || ''
const inr = n => '₹' + n.toLocaleString('en-IN')
const lev = (a, b) => { const d = Array.from({ length: a.length + 1 }, (_, i) => [i]); for (let j = 1; j <= b.length; j++) d[0][j] = j; for (let i = 1; i <= a.length; i++) for (let j = 1; j <= b.length; j++) d[i][j] = Math.min(d[i - 1][j] + 1, d[i][j - 1] + 1, d[i - 1][j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); return d[a.length][b.length] }
const VOCAB = [...new Set([...'delivery shipping refund return exchange cancel payment warranty contact support tracking recommend cheaper compare notebook pencil laptop monitor'.split(' '), ...products.flatMap(p => `${p.name} ${p.category}`.toLowerCase().split(/\W+/))])].filter(w => w.length > 3)
const fixTypos = s => s.replace(/[a-z]{4,}/g, w => VOCAB.includes(w) ? w : (VOCAB.find(v => Math.abs(v.length - w.length) <= 1 && lev(v, w) === 1) || w))
const top = (l, n = 3) => [...l].sort((a, b) => b.popularity - a.popularity).slice(0, n)
const list = l => l.map(p => `${p.name} (${inr(p.price)})`).join(', ')
const CATS = { desk: /lamp|desk|mat|tray|riser|monitor|organi/, writing: /pen|notebook|ink|pencil|writ/, carry: /bag|tote|sleeve|carry|pouch/, tech: /stand|cable|tech|laptop/ }
// Catalog-and-policy answers with no AI. Used only when the AI server can't be reached.
export function offlineAnswer(text, productId, lastIds = []) {
  const t = fixTypos(text.toLowerCase()), cur = products.find(p => String(p.id) === String(productId))
  const R = (reply, ids = []) => ({ reply, productIds: ids.map(p => p.id ?? p) })
  const describe = p => R(`${p.name} costs ${inr(p.price)}. ${p.description} Options: ${p.variants.join(', ')}. ${p.stock ? `In stock (${p.stock} available).` : 'Currently out of stock.'}`, [p])
  const last = lastIds.map(id => products.find(p => p.id === id)).filter(Boolean)
  if (/^(hi|hello|hey)\b/.test(t)) return R('Hello! What are you looking for today?')
  if (/thank/.test(t)) return R("You're welcome! Let me know if there's anything else.")
  if (/track|where is my order|order status/.test(t)) return R(P.tracking)
  if (/deliver|shipping|ship\b/.test(t)) return R(P.delivery)
  if (/refund/.test(t)) return R(P.refunds)
  if (/return|exchange/.test(t)) return R(P.returns)
  if (/cancel/.test(t)) return R(P.cancellation)
  if (/pay|card|upi/.test(t)) return R(P.payments)
  if (/warrant|repair/.test(t)) return R(P.warranty)
  if (/contact|support|hours|phone|email/.test(t)) return R(P.contact)
  if (cur && /\b(this|it|that)\b|variant|size|colou?r|stock|available/.test(t)) return describe(cur)
  if (last.length > 1 && /cheap|expens|compar|which|better|lower|higher|differ/.test(t)) { const s = [...last].sort((a, b) => a.price - b.price); return R(`${s[0].name} is the cheapest at ${inr(s[0].price)}. ${s.slice(1).map(p => `${p.name} is ${inr(p.price)}`).join('; ')}.`, last) }
  if (last.length === 1 && /\b(this|it|that)\b|variant|size|colou?r|stock|available/.test(t)) return describe(last[0])
  const cap = t.match(/(?:under|below|less than|within|upto|up to|<)\s*(?:₹|rs\.?|inr)?\s*(\d[\d,]*)/)?.[1]?.replace(/,/g, '')
  const cat = Object.keys(CATS).find(k => CATS[k].test(t))
  const words = t.split(/\W+/).filter(w => w.length > 2 && !/the|and|for|you|have|any|show|find|help|want|need|under|below|which|what|best|some|with/.test(w))
  let found = products.filter(p => (!cap || p.price <= Number(cap)) && (!cat || p.category === cat))
  const odd = words.filter(w => /^[a-z]{4,}$/.test(w) && !/under|below|less|than|within|upto|rupee|items?|products?|price|budget|cheap|affordable|good|have|show|looking|something|anything|sell|ones?/.test(w)), askingFor = /do you (have|sell)|looking for|show me|find me|\bany\b|under|below|upto|up to|within|less than/.test(t)
  const hit = found.filter(p => words.some(w => `${p.name} ${p.description}`.toLowerCase().includes(w)))
  if (hit.length) found = hit
  else if (odd.length && askingFor && !cat) { const alt = top(found); return R(`I couldn't find "${odd[0]}" in our catalog.${alt.length ? ` Here is what we have${cap ? ` under ${inr(Number(cap))}` : ''}: ${list(alt)}.` : ''}`, alt) }
  else if (!cap && !cat) {
    if (/recommend|gift|best|daily|suggest|find|product/.test(t)) return R(`Here are our most popular picks: ${list(top(products))}. Tell me your budget or what you'll use it for and I'll narrow it down.`, top(products))
    return R("I'm not sure I understood that. I can help with products, delivery, returns, warranty and contact details. What would you like to know?")
  }
  if (!found.length) return R(`I couldn't find a matching product${cap ? ` under ${inr(Number(cap))}` : ''}. Try a higher budget or a different category (${categories.map(c => c.name).join(', ')}).`)
  const pick = top(found); return R(`Here ${pick.length === 1 ? 'is a match' : 'are some matches'}: ${list(pick)}.`, pick)
}
export async function sendChat({ message, history, productId, lastIds }) {
  const ctrl = new AbortController(), timer = setTimeout(() => ctrl.abort(), 25000)
  const fallback = note => ({ ...offlineAnswer(message, productId, lastIds), note })
  try {
    const r = await fetch(`${API}/api/chat`, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ message, history, productId }), signal: ctrl.signal })
    const d = (r.headers.get('content-type') || '').includes('json') ? await r.json() : null
    if (r.ok && d?.reply) return d
    return fallback(d?.error?.message || 'The AI assistant is not available right now. Showing catalog-only answers.')
  } catch { return fallback('Could not reach the AI server. Showing catalog-only answers (no AI).') } finally { clearTimeout(timer) }
}
