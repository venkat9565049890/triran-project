const C = ['#2d3a35', '#b98b5a', '#4a5a52', '#b8923a', '#1f4d3f', '#35556b', '#8a6a4a', '#2e4a8a', '#6b7a3a', '#7e8a90', '#9aa3a8', '#5d6b64']
const dk = '#16241f'
const draw = (id) => { const c = C[id - 1]; switch (id) {
  case 1: return `<ellipse cx="400" cy="830" rx="170" ry="24" fill="${c}"/><path d="M400 820 L320 560 L470 330" stroke="${c}" stroke-width="22" fill="none" stroke-linecap="round" stroke-linejoin="round"/><path d="M430 320 L600 360 L540 470Z" fill="${c}"/><circle cx="560" cy="440" r="14" fill="#fff6c2"/>`
  case 2: return `<rect x="150" y="430" width="500" height="60" rx="10" fill="${c}"/><rect x="190" y="490" width="60" height="320" fill="${c}" opacity=".85"/><rect x="550" y="490" width="60" height="320" fill="${c}" opacity=".85"/><rect x="300" y="520" width="200" height="90" rx="8" fill="#fff" opacity=".25"/>`
  case 3: return `<rect x="110" y="540" width="580" height="240" rx="18" fill="${c}"/><rect x="190" y="590" width="300" height="90" rx="10" fill="#fff" opacity=".18"/><circle cx="580" cy="640" r="40" fill="#fff" opacity=".18"/>`
  case 4: return `<g transform="rotate(-12 300 560)"><rect x="270" y="400" width="22" height="170" rx="11" fill="${dk}"/></g><g transform="rotate(10 400 560)"><rect x="400" y="380" width="22" height="190" rx="11" fill="${C[4]}"/></g><path d="M140 560 L660 560 L610 760 L190 760Z" fill="${c}"/>`
  case 5: return `<g transform="rotate(-35 400 520)"><rect x="280" y="490" width="340" height="60" rx="30" fill="${c}"/><rect x="520" y="490" width="14" height="60" fill="#fff" opacity=".35"/><path d="M285 490 L190 520 L285 550Z" fill="#c8c8c0"/></g>`
  case 6: return `<rect x="230" y="260" width="340" height="540" rx="14" fill="${c}"/><rect x="520" y="260" width="24" height="540" fill="#fff" opacity=".2"/><rect x="290" y="340" width="150" height="70" rx="6" fill="#fff" opacity=".85"/>`
  case 7: return [0, 1, 2, 3, 4].map(i => `<rect x="${210 + i * 80}" y="380" width="26" height="130" rx="6" fill="${['#c9a15a', '#b3503c', '#3d6b5a', '#2e4a8a', '#d9b24a'][i]}"/>`).join('') + `<rect x="150" y="480" width="500" height="260" rx="40" fill="${c}"/><rect x="380" y="470" width="44" height="280" fill="${dk}" opacity=".5"/>`
  case 8: return ['#2e4a8a', '#1f4d3f', '#8a3b2e'].map((h, i) => `<rect x="${210 + i * 130}" y="560" width="110" height="220" rx="16" fill="${h}"/><rect x="${240 + i * 130}" y="500" width="50" height="70" rx="6" fill="${dk}"/><rect x="${225 + i * 130}" y="640" width="80" height="60" rx="6" fill="#fff" opacity=".85"/>`).join('')
  case 9: return `<path d="M300 440 C300 220 500 220 500 440" stroke="${c}" stroke-width="20" fill="none"/><path d="M200 440 H600 L630 800 H170Z" fill="${c}"/><rect x="300" y="540" width="200" height="110" rx="10" fill="#fff" opacity=".18"/>`
  case 10: return `<rect x="170" y="400" width="460" height="380" rx="30" fill="${c}"/><path d="M170 430 Q400 580 630 430 V400 H170Z" fill="#fff" opacity=".2"/><circle cx="400" cy="520" r="16" fill="${dk}"/>`
  case 11: return `<path d="M180 790 L400 540 L620 790" stroke="${c}" stroke-width="26" fill="none" stroke-linecap="round" stroke-linejoin="round"/><rect x="190" y="470" width="420" height="36" rx="12" fill="${c}" transform="rotate(-14 400 490)"/>`
  default: return [0, 1, 2].map(i => `<circle cx="${260 + i * 140}" cy="${600 + (i % 2) * 60}" r="70" fill="none" stroke="${['#5d6b64', '#b98b5a', '#2e4a8a'][i]}" stroke-width="26"/>`).join('') } }
export const ph = (seed) => {
  const s = String(seed).replace('haldane', ''); let id = 1, v = 0, body
  if (s === 'hero') body = `<g transform="translate(-140 60)">${draw(1)}</g><g transform="translate(330 330) scale(.6)">${draw(6)}</g><g transform="translate(70 450) scale(.7)">${draw(5)}</g>`
  else if (s.startsWith('cat')) { id = { desk: 1, writing: 5, carry: 9, tech: 11 }[s.slice(3)] || 1; body = draw(id) }
  else { [id, v] = s.split('x').map(Number); id = id || 1; v = v || 0; body = draw(id) }
  const t = v === 1 ? 'translate(-130 -170) scale(1.35)' : v === 2 ? 'rotate(-6 400 600)' : '', h = id * 47 % 360
  const svg = `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 1000"><defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="hsl(${h},25%,${90 - v * 4}%)"/><stop offset="1" stop-color="hsl(${h + 30},28%,${78 - v * 4}%)"/></linearGradient></defs><rect width="800" height="1000" fill="url(#g)"/><ellipse cx="400" cy="850" rx="270" ry="26" fill="#000" opacity=".1"/><g transform="${t}">${body}</g></svg>`
  return 'data:image/svg+xml;utf8,' + encodeURIComponent(svg) }
