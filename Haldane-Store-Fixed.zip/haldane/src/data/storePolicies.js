import { SHIPPING } from './products.js'
// Single source of truth for store policies. Used by the server (AI context) and the offline assistant.
// Values marked [CONFIGURE] were not supplied: replace them with your real policy before launch.
export const policies = {
  storeName: 'Haldane Store', currency: 'INR (₹)',
  delivery: `Standard shipping costs ₹${SHIPPING.flat}. Orders of ₹${SHIPPING.freeOver} or more ship free. Estimated delivery time: [CONFIGURE: e.g. 3-7 business days]. Delivery regions (PIN codes served): [CONFIGURE].`,
  returns: 'Returns are accepted within 30 days in original condition. Exchanges: [CONFIGURE: exchange eligibility].',
  refunds: 'Refund processing time: [CONFIGURE: e.g. 5-10 business days after the return is received].',
  cancellation: 'Order cancellation policy: [CONFIGURE: cancellation window].',
  payments: 'Accepted payment methods: [CONFIGURE: e.g. UPI, cards, net banking, cash on delivery]. This site is currently a frontend demo, so no real payment or order is processed.',
  warranty: '2-year warranty with free repairs on hinges and seams.',
  contact: 'Support email: [CONFIGURE: support email]. Phone: [CONFIGURE]. Hours: [CONFIGURE].',
  tracking: 'Order tracking: no live order system is connected yet, so order status cannot be looked up. Tracking URL: [CONFIGURE].',
}
