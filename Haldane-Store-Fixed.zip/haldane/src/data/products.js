// Real photography hosted by Unsplash. These are photographic references, not generated placeholders.
// The shop can be used without storing image binaries in the project. Keep an internet connection
// available for images; replace any URL with your own product photography whenever available.
const img = (photoId, width = 900) =>
  `https://images.unsplash.com/${photoId}?auto=format&fit=crop&w=${width}&q=85`

export const categories = [
  { id: 'desk', name: 'Desk Objects', blurb: 'Thoughtful tools for your workspace' },
  { id: 'writing', name: 'Writing', blurb: 'Pens, paper and ink for daily use' },
  { id: 'carry', name: 'Carry', blurb: 'Everyday bags and sleeves' },
  { id: 'tech', name: 'Tech Support', blurb: 'Useful accessories for your setup' },
]

export const categoryImages = {
  desk: img('photo-1507473885765-e6ed057f782c'),
  writing: img('photo-1517842645767-c639042777db'),
  carry: img('photo-1544816155-12df9643f363'),
  tech: img('photo-1498050108023-c5249f4df085'),
}
export const heroImage = img('photo-1498050108023-c5249f4df085', 1400)

const photos = {
  1: ['photo-1507473885765-e6ed057f782c', 'photo-1493666438817-866a91353ca9', 'photo-1507473885765-e6ed057f782c'],
  2: ['photo-1498050108023-c5249f4df085', 'photo-1497366754035-f200968a6e72', 'photo-1497366811353-6870744d04b2'],
  3: ['photo-1499951360447-b19be8fe80f5', 'photo-1497366754035-f200968a6e72', 'photo-1498050108023-c5249f4df085'],
  4: ['photo-1494438639946-1ebd1d20bf85', 'photo-1455390582262-044cdead277a', 'photo-1499951360447-b19be8fe80f5'],
  5: ['photo-1455390582262-044cdead277a', 'photo-1455390582262-044cdead277a', 'photo-1517842645767-c639042777db'],
  6: ['photo-1517842645767-c639042777db', 'photo-1455390582262-044cdead277a', 'photo-1494438639946-1ebd1d20bf85'],
  7: ['photo-1453738773917-9c3eff1db985', 'photo-1517842645767-c639042777db', 'photo-1494438639946-1ebd1d20bf85'],
  8: ['photo-1494438639946-1ebd1d20bf85', 'photo-1455390582262-044cdead277a', 'photo-1517842645767-c639042777db'],
  9: ['photo-1544816155-12df9643f363', 'photo-1553062407-98eeb64c6a62', 'photo-1590874103328-eac38a683ce7'],
  10: ['photo-1517336714731-489689fd1ca8', 'photo-1544816155-12df9643f363', 'photo-1498050108023-c5249f4df085'],
  11: ['photo-1525547719571-a2d4ac8945e2', 'photo-1498050108023-c5249f4df085', 'photo-1496181133206-80ce9b88a853'],
  12: ['photo-1558618666-fcd25c85cd64', 'photo-1498050108023-c5249f4df085', 'photo-1525547719571-a2d4ac8945e2'],
}
const photo = (id, n) => img(photos[id]?.[n - 1] || photos[id]?.[0] || 'photo-1498050108023-c5249f4df085')
const P = (id, name, category, price, orig, rating, reviews, stock, pop, variants, description) =>
  ({ id, name, category, price, originalPrice: orig, rating, reviews, stock, popularity: pop, newest: id, variants, description,
     image: photo(id, 1),
     gallery: [1, 2, 3].map(n => photo(id, n)),
     specs: ['Made in small batches', '2-year warranty', 'Free repairs on hinges and seams'] })
export const products = [
  P(1, 'Jaipur Brass Table Lamp', 'desk', 3499, 4299, 4.8, 214, 12, 98, ['Antique Brass', 'Matte Black'], 'A hand-finished brass lamp with a warm LED bulb and a weighted base that stays put on a busy desk.'),
  P(2, 'Sheesham Monitor Riser', 'desk', 2499, null, 4.6, 98, 25, 80, ['Natural Sheesham', 'Walnut Finish'], 'Solid sheesham wood riser with a hidden drawer for keyboards, cables and loose pens.'),
  P(3, 'Wool-Felt Desk Mat', 'desk', 1299, 1599, 4.7, 340, 60, 92, ['Charcoal', 'Indigo', 'Natural'], 'A 3mm wool-felt mat sized to hold keyboard, mouse and a cup of chai.'),
  P(4, 'Moradabad Brass Pen Tray', 'desk', 899, null, 4.5, 61, 0, 40, ['Brass'], 'Hand-cast brass tray with a felt base. Out of stock until the next batch.'),
  P(5, 'Ebonite Fountain Pen', 'writing', 1899, 2299, 4.9, 502, 18, 99, ['Fine', 'Medium'], 'A turned ebonite fountain pen with a steel nib and a converter included. Smooth on everyday paper.'),
  P(6, 'Handmade Paper Notebook', 'writing', 349, null, 4.8, 788, 140, 95, ['A5', 'A6'], 'Lay-flat stitched notebook with handmade cotton paper that handles fountain pen ink.'),
  P(7, 'Block-Print Pencil Roll', 'writing', 649, 799, 4.4, 77, 9, 55, ['Indigo Block Print', 'Madder Red'], 'Hand block-printed cotton roll that holds twelve pencils and a ruler. Rolls up, ties shut.'),
  P(8, 'Calligraphy Ink Set of Five', 'writing', 749, null, 4.6, 129, 32, 61, ['Standard'], 'Five 30ml bottles of fade-resistant ink in muted working colours.'),
  P(9, 'Khadi Canvas Tote', 'carry', 1799, 2199, 4.7, 256, 14, 88, ['Olive', 'Black', 'Natural'], 'Sturdy khadi canvas tote with a padded 16-inch laptop pocket and a zip inner pouch.'),
  P(10, 'Kantha Laptop Sleeve 14"', 'carry', 1499, null, 4.5, 143, 40, 70, ['Indigo Kantha', 'Mustard Kantha'], 'Hand-stitched kantha sleeve with a soft lining and a snug fit for 14-inch laptops.'),
  P(11, 'Aluminium Laptop Stand', 'tech', 2199, 2599, 4.8, 410, 22, 90, ['Silver', 'Graphite'], 'Folds flat to 8mm. Raises your screen to eye level.'),
  P(12, 'Leather Cable Keepers', 'tech', 499, null, 4.3, 95, 75, 50, ['Set of 6'], 'Vegetable-tanned leather ties that keep cables sorted and labelled.'),
]
export const promoCodes = {
  WELCOME10: { type: 'percent', value: 10, label: '10% off' },
  HALDANE20: { type: 'percent', value: 20, label: '20% off' },
  FLAT100: { type: 'fixed', value: 100, label: '₹100 off' },
}
export const SHIPPING = { flat: 79, freeOver: 999 }
