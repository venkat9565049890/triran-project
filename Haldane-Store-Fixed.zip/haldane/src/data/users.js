// Demo accounts. This is a static site: these are visible in the shipped code, so this is not real security.
export const USERS = [
  { username: 'demo', password: 'Haldane@123', name: 'Demo Shopper' },
  { username: 'admin', password: 'Admin@123', name: 'Store Admin' },
]
