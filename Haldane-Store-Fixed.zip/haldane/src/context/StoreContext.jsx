import { createContext, useContext, useEffect, useState, useCallback, useMemo } from 'react'
const Ctx = createContext(null)
export const useStore = () => useContext(Ctx)
const load = (k, d) => { try { return JSON.parse(localStorage.getItem(k)) ?? d } catch { return d } }
export function StoreProvider({ children }) {
  const [cart, setCart] = useState(() => load('haldane-cart', []))
  const [wishlist, setWishlist] = useState(() => load('haldane-wish', []))
  const [toasts, setToasts] = useState([]), [drawer, setDrawer] = useState(false), [recent, setRecent] = useState(() => load('haldane-recent', []))
  useEffect(() => { try { localStorage.setItem('haldane-recent', JSON.stringify(recent)) } catch {} }, [recent])
  const viewed = useCallback(id => { setRecent(r => [id, ...r.filter(x => x !== id)].slice(0, 6)) }, [])
  useEffect(() => { try { localStorage.setItem('haldane-cart', JSON.stringify(cart)) } catch {} }, [cart])
  useEffect(() => { try { localStorage.setItem('haldane-wish', JSON.stringify(wishlist)) } catch {} }, [wishlist])
  const toast = useCallback((msg) => {
    const id = Date.now() + Math.random()
    setToasts(t => [...t, { id, msg }])
    setTimeout(() => setToasts(t => t.filter(x => x.id !== id)), 2800)
  }, [])
  const addToCart = (p, variant, qty = 1) => {
    if (p.stock <= 0) return toast('This item is out of stock')
    setCart(c => {
      const key = `${p.id}-${variant}`, ex = c.find(i => i.key === key)
      if (ex) return c.map(i => i.key === key ? { ...i, qty: Math.min(i.qty + qty, p.stock, 10) } : i)
      return [...c, { key, id: p.id, variant, qty: Math.min(qty, p.stock, 10) }]
    })
    setDrawer(true)
  }
  const setQty = (key, qty, max = 10) => setCart(c => c.map(i => i.key === key ? { ...i, qty: Math.max(1, Math.min(max, qty || 1)) } : i))
  const removeItem = (key) => setCart(c => c.filter(i => i.key !== key))
  const clearCart = () => setCart([])
  const toggleWish = (p) => setWishlist(w => { const has = w.includes(p.id); toast(has ? 'Removed from wishlist' : 'Saved to wishlist'); return has ? w.filter(x => x !== p.id) : [...w, p.id] })
  const cartCount = useMemo(() => cart.reduce((s, i) => s + i.qty, 0), [cart])
  return <Ctx.Provider value={{ drawer, setDrawer, recent, viewed, cart, wishlist, toasts, addToCart, setQty, removeItem, clearCart, toggleWish, cartCount, toast }}>{children}</Ctx.Provider>
}
