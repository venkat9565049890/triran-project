import { createContext, useContext, useState } from 'react'
import { USERS } from '../data/users.js'
const Ctx = createContext(null)
export const useAuth = () => useContext(Ctx)
const read = k => { try { return JSON.parse(localStorage.getItem(k)) } catch { return null } }
const save = (k, v) => { try { localStorage.setItem(k, JSON.stringify(v)) } catch {} }
export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => read('haldane-user')), [accounts, setAccounts] = useState(() => read('haldane-accounts') || [])
  const all = () => [...USERS, ...accounts]
  const start = m => { const u = { username: m.username, name: m.name }; setUser(u); save('haldane-user', u) }
  const login = (username, password) => { const m = all().find(x => x.username.toLowerCase() === username.toLowerCase() && x.password === password); if (m) start(m); return !!m }
  const register = ({ name, username, password }) => {
    if (all().some(x => x.username.toLowerCase() === username.toLowerCase())) return 'That username is taken. Choose another.'
    const a = [...accounts, { name, username, password }]; setAccounts(a); save('haldane-accounts', a); start({ name, username }); return ''
  }
  const logout = () => { setUser(null); try { localStorage.removeItem('haldane-user') } catch {} }
  return <Ctx.Provider value={{ user, login, register, logout }}>{children}</Ctx.Provider>
}
