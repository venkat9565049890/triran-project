import { useState } from 'react'
import { Link } from 'react-router-dom'
import { ShoppingBag, Trash2, Heart, CheckCircle } from 'lucide-react'
import { products, promoCodes, SHIPPING } from '../data/products.js'
import { useStore } from '../context/StoreContext.jsx'
import { SafeImg, QuantitySelector, EmptyState, Breadcrumbs, money } from '../components/Shared.jsx'
const fields = [['name', 'Full name', 'text'], ['email', 'Email', 'email'], ['phone', 'Mobile number', 'tel'], ['address', 'Shipping address', 'text'], ['city', 'City', 'text'], ['state', 'State', 'text'], ['postal', 'PIN code', 'text'], ['country', 'Country', 'text']]
const check = v => { const e = {}
  if (v.name.trim().length < 2) e.name = 'Enter your full name'
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(v.email)) e.email = 'Enter a valid email address'
  if (!/^(\+91)?[6-9]\d{9}$/.test(v.phone.replace(/[\s-]/g, ''))) e.phone = 'Enter a valid 10-digit Indian mobile number'
  ;['address', 'city', 'state', 'country'].forEach(k => { if (!v[k].trim()) e[k] = 'This field is required' })
  if (!/^[1-9]\d{5}$/.test(v.postal.trim())) e.postal = 'Enter a valid 6-digit PIN code'
  return e }
export default function CartCheckout() {
  const { cart, setQty, removeItem, clearCart, toggleWish, wishlist, cartCount } = useStore()
  const [code, setCode] = useState(''), [promo, setPromo] = useState(null), [pErr, setPErr] = useState('')
  const [v, setV] = useState({ ...Object.fromEntries(fields.map(f => [f[0], ''])), country: 'India' }), [errs, setErrs] = useState({}), [done, setDone] = useState(null)
  const lines = cart.map(i => ({ ...i, p: products.find(p => p.id === i.id) })).filter(l => l.p)
  const subtotal = lines.reduce((s, l) => s + l.p.price * l.qty, 0)
  const discount = promo ? Math.min(subtotal, promo.type === 'percent' ? Math.round(subtotal * promo.value) / 100 : promo.value) : 0
  const after = Math.max(0, subtotal - discount), shipping = lines.length === 0 || after >= SHIPPING.freeOver ? 0 : SHIPPING.flat, total = Math.max(0, after + shipping)
  const apply = e => { e.preventDefault(); const c = promoCodes[code.trim().toUpperCase()]; if (c) { setPromo(c); setPErr('') } else { setPromo(null); setPErr('That code isn\'t valid. Try WELCOME10.') } }
  const submit = e => { e.preventDefault(); const er = check(v); setErrs(er); if (Object.keys(er).length) return document.querySelector('[aria-invalid="true"]')?.focus()
    setDone({ name: v.name, email: v.email, total, ref: 'DEMO-' + Date.now().toString().slice(-6) }); clearCart() }
  if (done) return <div className="wrap"><EmptyState icon={CheckCircle} title="Demo order received" text={`Thanks ${done.name}. This is a frontend demo: no payment was taken and no real order was placed. Reference ${done.ref}, total ${money(done.total)}.`}><Link className="btn" to="/shop">Continue shopping</Link></EmptyState></div>
  if (!lines.length) return <div className="wrap"><EmptyState icon={ShoppingBag} title="Your cart is empty" text="Add something to your desk and it will show up here."><Link className="btn" to="/shop">Browse products</Link></EmptyState></div>
  return <div className="wrap cart"><Breadcrumbs items={[{ label: 'Home', to: '/' }, { label: 'Cart' }]} /><h1>Cart and checkout <small>({cartCount})</small></h1>
    <p className="demo-note" role="note">Frontend demo: no payment details are collected and no real order is processed.</p>
    <div className="cart-grid"><div><ul className="lines">{lines.map(l => <li key={l.key}><SafeImg src={l.p.image} alt={l.p.name} /><div><Link to={`/product/${l.p.id}`}><strong>{l.p.name}</strong></Link><p>{l.variant}</p><p>{money(l.p.price)}</p>
      <div className="row"><button className="link-btn" onClick={() => { if (!wishlist.includes(l.p.id)) toggleWish(l.p); removeItem(l.key) }}><Heart size={14} /> Save for later</button><button className="link-btn" onClick={() => removeItem(l.key)}><Trash2 size={14} /> Remove</button></div></div>
      <div className="line-end"><QuantitySelector value={l.qty} max={Math.max(1, Math.min(10, l.p.stock))} onChange={n => setQty(l.key, n, Math.min(10, l.p.stock))} /><strong>{money(l.p.price * l.qty)}</strong></div></li>)}</ul>
      <Link to="/shop">← Continue shopping</Link>
      <form className="checkout" onSubmit={submit} noValidate><h2>Shipping details</h2><div className="form-grid">{fields.map(([k, label, type]) => <div key={k} className={k === 'address' ? 'full' : ''}><label htmlFor={k}>{label}</label>
        <input id={k} type={type} className="field" value={v[k]} aria-invalid={!!errs[k]} aria-describedby={`${k}-e`} onChange={e => setV({ ...v, [k]: e.target.value })} /><p id={`${k}-e`} className="error">{errs[k]}</p></div>)}</div>
        <h2>Order review</h2><p>{lines.length} item type(s), {cartCount} unit(s), total {money(total)}. Shipping to {v.city || 'your city'}.</p><button className="btn big" type="submit">Place demo order</button></form></div>
      <aside className="summary"><h2>Order summary</h2>
        <form className="row" onSubmit={apply}><label htmlFor="promo" className="sr">Promo code</label><input id="promo" className="field" value={code} onChange={e => setCode(e.target.value)} placeholder="Promo code" /><button className="btn ghost">Apply</button></form>
        <p className="error">{pErr}</p>{promo && <p className="ok">Code applied: {promo.label}</p>}
        <dl><dt>Subtotal</dt><dd>{money(subtotal)}</dd><dt>Discount</dt><dd>−{money(discount)}</dd><dt>Shipping</dt><dd>{shipping ? money(shipping) : 'Free'}</dd><dt className="tot">Total</dt><dd className="tot">{money(total)}</dd></dl>
        <small>Demo codes: WELCOME10, HALDANE20, FLAT100</small></aside></div></div>
}
