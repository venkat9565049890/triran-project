import { useState } from 'react'
import { Eye, EyeOff } from 'lucide-react'
import { useAuth } from '../context/AuthContext.jsx'
import { ph } from '../data/ph.js'
export default function Login() {
  const { login, register } = useAuth(); const [mode, setMode] = useState('in'), [f, setF] = useState({ name: '', username: '', password: '', confirm: '' }), [show, setShow] = useState(false), [err, setErr] = useState('')
  const up = mode === 'up', set = k => e => setF({ ...f, [k]: e.target.value })
  const submit = e => { e.preventDefault(); const u = f.username.trim()
    if (!u || !f.password) return setErr('Enter your username and password.')
    if (!up) return login(u, f.password) ? null : (setErr('Incorrect username or password.'), setF({ ...f, password: '' }))
    if (f.name.trim().length < 2) return setErr('Enter your name.')
    if (u.length < 3 || /\s/.test(u)) return setErr('Username needs 3 or more characters, with no spaces.')
    if (f.password.length < 6 || !/\d/.test(f.password) || !/[A-Za-z]/.test(f.password)) return setErr('Password needs 6 or more characters, with a letter and a number.')
    if (f.password !== f.confirm) return setErr('Passwords do not match.')
    setErr(register({ name: f.name.trim(), username: u, password: f.password })) }
  const switchMode = m => { setMode(m); setErr('') }
  return <div className="login"><div className="login-art" style={{ backgroundImage: `url("${import.meta.env.BASE_URL}images/hero.jpg"), url("${ph('haldanehero')}")` }}><div><span className="logo"><span className="logo-mark">H</span>aldane</span><p>Tools for the desk you actually use.</p></div></div>
    <main className="login-form"><form onSubmit={submit} noValidate><h1>{up ? 'Create account' : 'Sign in'}</h1><p className="sub">{up ? 'Join Haldane in under a minute.' : 'Log in to browse the Haldane store.'}</p>
      {up && <><label htmlFor="nm">Full name</label><input id="nm" className="field" autoComplete="name" value={f.name} onChange={set('name')} /></>}
      <label htmlFor="u">Username</label><input id="u" className="field" autoFocus autoComplete="username" value={f.username} onChange={set('username')} />
      <label htmlFor="pw">Password</label><div className="pw"><input id="pw" className="field" type={show ? 'text' : 'password'} autoComplete={up ? 'new-password' : 'current-password'} value={f.password} onChange={set('password')} />
        <button type="button" className="icon-btn" aria-label={show ? 'Hide password' : 'Show password'} aria-pressed={show} onClick={() => setShow(!show)}>{show ? <EyeOff size={18} /> : <Eye size={18} />}</button></div>
      {up && <><label htmlFor="cf">Confirm password</label><input id="cf" className="field" type={show ? 'text' : 'password'} autoComplete="new-password" value={f.confirm} onChange={set('confirm')} /></>}
      <p className="error" role="alert">{err}</p><button className="btn big" type="submit">{up ? 'Create account' : 'Sign in'}</button>
      <button type="button" className="btn big ghost" onClick={() => login('demo', 'Haldane@123')}>Continue with demo account</button>
      <p className="switch">{up ? 'Have an account?' : 'New here?'} <button type="button" className="link-btn" onClick={() => switchMode(up ? 'in' : 'up')}>{up ? 'Sign in' : 'Create an account'}</button></p>
      <small className="muted">Static frontend demo. Accounts are stored in this browser only.</small></form></main></div>
}
