import { ph } from '../data/ph.js'
import { useState } from 'react'
import { Truck, ShieldCheck, RotateCcw, Wrench } from 'lucide-react'
import { Link } from 'react-router-dom'
import { categories, products, heroImage } from '../data/products.js'
import { ProductGrid, CategoryCard, SafeImg, RatingStars } from '../components/Shared.jsx'
import { useStore } from '../context/StoreContext.jsx'
const reviews = [
  { n: 'Ananya R.', t: 'The Jaipur brass lamp replaced three lamps in my studio. Still the nicest object on my desk.', r: 5 },
  { n: 'Rohan M.', t: 'The handmade paper notebook handles fountain pen ink without bleed. I have bought six.', r: 5 },
  { n: 'Kavya S.', t: 'The khadi tote carries my 16-inch laptop and tiffin. The canvas wears in beautifully.', r: 4 },
]
export default function Home() {
  const { toast } = useStore(); const [email, setEmail] = useState(''); const [err, setErr] = useState('')
  const sub = e => { e.preventDefault()
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(email)) return setErr('Enter a valid email address, like name@example.com')
    setErr(''); setEmail(''); toast('Subscribed. Check your inbox for the welcome note.') }
  return <>
    <section className="hero wrap"><div className="hero-text"><h1>Tools for the desk you actually use.</h1>
      <p>Desk goods handcrafted by Indian artisans in small batches, built to be repaired, not replaced.</p>
      <div className="row"><Link className="btn" to="/shop">Shop all products</Link><Link className="btn ghost" to="/shop?category=writing">Browse writing</Link></div></div>
      <div className="hero-img"><SafeImg src={heroImage} alt="A tidy workspace with desk accessories" /></div></section>
    <div className="wrap trust">{[[Truck, "Free shipping over ₹999"], [RotateCcw, "30-day returns"], [Wrench, "Free repairs"], [ShieldCheck, "2-year warranty"]].map(([I, t]) => <div key={t}><I size={20} />{t}</div>)}</div>
    <section className="wrap sec"><h2>Shop by category</h2><div className="cats">{categories.map(c => <CategoryCard key={c.id} c={c} />)}</div></section>
    <section className="wrap sec"><div className="sec-head"><h2>Featured</h2><Link to="/shop">View all</Link></div><ProductGrid items={products.slice(0, 4)} /></section>
    <section className="wrap sec"><div className="sec-head"><h2>Best sellers</h2><Link to="/shop?sort=popular">See more</Link></div>
      <ProductGrid items={[...products].sort((a, b) => b.popularity - a.popularity).slice(0, 4)} /></section>
    <section className="promo"><div className="wrap promo-in"><div><h2>Spring reset: 20% off with HALDANE20</h2><p>Apply at checkout on any order. Ends when the batch does.</p></div><Link className="btn light" to="/shop">Start shopping</Link></div></section>
    <section className="wrap sec"><h2>What customers say</h2><div className="reviews">{reviews.map(r => <figure key={r.n}><RatingStars rating={r.r} /><blockquote>{r.t}</blockquote><figcaption>{r.n}</figcaption></figure>)}</div></section>
    <section className="wrap sec"><form className="news" onSubmit={sub} noValidate><div><h2>Notes from the workshop</h2><p>New batches and repair guides, once a month.</p></div>
      <div><label htmlFor="nl" className="sr">Email address</label><div className="row"><input id="nl" type="email" value={email} onChange={e => setEmail(e.target.value)} placeholder="you@example.com" aria-invalid={!!err} aria-describedby="nl-e" /><button className="btn">Subscribe</button></div><p id="nl-e" className="error">{err}</p></div></form></section>
  </>
}
