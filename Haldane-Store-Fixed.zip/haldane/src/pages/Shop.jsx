import { useEffect, useMemo, useState } from 'react'
import { useSearchParams } from 'react-router-dom'
import { SlidersHorizontal, X } from 'lucide-react'
import { products, categories } from '../data/products.js'
import { ProductGrid, Breadcrumbs, EmptyState } from '../components/Shared.jsx'
import { useStore } from '../context/StoreContext.jsx'
export default function Shop() {
  const [sp, setSp] = useSearchParams(); const { wishlist } = useStore(); const [drawer, setDrawer] = useState(false), [loading, setLoading] = useState(true)
  useEffect(() => { const t = setTimeout(() => setLoading(false), 600); return () => clearTimeout(t) }, [])
  const q = sp.get('q') || '', cat = sp.get('category') || '', sort = sp.get('sort') || 'popular', wish = sp.get('wishlist') === '1', max = Number(sp.get('max')) || 4000
  const set = (k, v) => { const n = new URLSearchParams(sp); v ? n.set(k, v) : n.delete(k); setSp(n, { replace: true }) }
  const items = useMemo(() => {
    let l = products.filter(p => (!cat || p.category === cat) && p.price <= max && (!wish || wishlist.includes(p.id)) && (!q || `${p.name} ${p.description}`.toLowerCase().includes(q.toLowerCase())))
    const s = { 'price-asc': (a, b) => a.price - b.price, 'price-desc': (a, b) => b.price - a.price, newest: (a, b) => b.newest - a.newest, popular: (a, b) => b.popularity - a.popularity }[sort]
    return [...l].sort(s)
  }, [q, cat, sort, wish, max, wishlist])
  const filters = <div className="filters"><h2>Filters</h2>
    <fieldset><legend>Category</legend>{[{ id: '', name: 'All' }, ...categories].map(c => <label key={c.id}><input type="radio" name="cat" checked={cat === c.id} onChange={() => set('category', c.id)} />{c.name}</label>)}</fieldset>
    <fieldset><legend>Max price: ₹{max.toLocaleString('en-IN')}</legend><input type="range" aria-label="Maximum price" min="500" max="4000" step="100" value={max} onChange={e => set('max', e.target.value === '4000' ? '' : e.target.value)} /></fieldset>
    <label><input type="checkbox" checked={wish} onChange={e => set('wishlist', e.target.checked ? '1' : '')} />Wishlist only</label>
    <button className="btn ghost" onClick={() => { setSp({}); setDrawer(false) }}>Clear all filters</button></div>
  return <div className="wrap shop"><Breadcrumbs items={[{ label: 'Home', to: '/' }, { label: 'Shop' }]} />
    <h1>{cat ? categories.find(c => c.id === cat)?.name : 'All products'}</h1>
    <div className="toolbar"><button className="btn ghost filter-btn" onClick={() => setDrawer(true)}><SlidersHorizontal size={16} /> Filters</button>
      <div><label className="sr" htmlFor="sq">Search in shop</label><input id="sq" className="field" type="search" value={q} onChange={e => set('q', e.target.value)} placeholder="Search products" /></div>
      <p aria-live="polite">{items.length} {items.length === 1 ? 'product' : 'products'}</p>
      <div><label className="sr" htmlFor="so">Sort by</label><select id="so" className="field" value={sort} onChange={e => set('sort', e.target.value)}>
        <option value="popular">Most popular</option><option value="newest">Newest</option><option value="price-asc">Price: low to high</option><option value="price-desc">Price: high to low</option></select></div></div>
    <div className="shop-body"><aside className={'side' + (drawer ? ' open' : '')} aria-label="Filters"><button className="icon-btn close-d" aria-label="Close filters" onClick={() => setDrawer(false)}><X /></button>{filters}</aside>
      {drawer && <div className="scrim" onClick={() => setDrawer(false)} />}
      <div>{loading ? <div className="grid" aria-busy="true">{Array.from({ length: 6 }, (_, i) => <div key={i} className="card skel" />)}</div> : items.length ? <ProductGrid items={items} /> : <EmptyState title="No products match" text="Try a different search or remove a filter."><button className="btn" onClick={() => setSp({})}>Clear all filters</button></EmptyState>}</div></div></div>
}
