import { useEffect, useState } from 'react'
import { Link, useParams } from 'react-router-dom'
import { Truck, RotateCcw, ChevronDown, Check } from 'lucide-react'
import { products } from '../data/products.js'
import { Breadcrumbs, SafeImg, PriceDisplay, RatingStars, QuantitySelector, WishlistButton, ProductGrid, EmptyState, discountPct } from '../components/Shared.jsx'
import { useStore } from '../context/StoreContext.jsx'
export default function ProductDetails() {
  const { id } = useParams(); const p = products.find(x => String(x.id) === id)
  if (!p) return <div className="wrap"><EmptyState title="Product not found" text="That product doesn't exist or has been removed."><Link className="btn" to="/shop">Back to shop</Link></EmptyState></div>
  return <Detail key={p.id} p={p} />
}
function Detail({ p }) {
  const { addToCart, recent, viewed } = useStore(); useEffect(() => { viewed(p.id) }, [p.id, viewed]); const [zoom, setZoom] = useState(false), [pos, setPos] = useState([50, 50]); const [img, setImg] = useState(0), [variant, setVariant] = useState(p.variants[0]), [qty, setQty] = useState(1), [added, setAdded] = useState(false), [open, setOpen] = useState(0)
  const w = [5, 4, 3, 2, 1].map(s => Math.max(2, Math.exp(-((s - p.rating) ** 2) * 1.1) * 100)), tw = w.reduce((a, b) => a + b), dist = [5, 4, 3, 2, 1].map((s, i) => [s, Math.round(w[i] / tw * 100)]), rv = recent.filter(x => x !== p.id).map(x => products.find(q => q.id === x)).filter(Boolean).slice(0, 4)
  const out = p.stock === 0, max = Math.min(p.stock, 10), d = discountPct(p)
  const add = () => { if (out) return; addToCart(p, variant, qty); setAdded(true); setTimeout(() => setAdded(false), 2000) }
  const acc = [['Specifications', <ul>{p.specs.map(s => <li key={s}>{s}</li>)}</ul>], ['Shipping and returns', <p>Free standard shipping over ₹999, otherwise ₹79. Returns accepted within 30 days in original condition.</p>], ['Care', <p>Wipe with a dry cloth. Contact us for free repairs within the warranty period.</p>]]
  return <div className="wrap pd"><Breadcrumbs items={[{ label: 'Home', to: '/' }, { label: 'Shop', to: '/shop' }, { label: p.name }]} />
    <div className="pd-main"><div className="gallery"><div className="thumbs" role="group" aria-label="Product images">{p.gallery.map((g, i) => <button key={i} aria-label={`Show image ${i + 1}`} aria-pressed={img === i} className={img === i ? 'on' : ''} onClick={() => setImg(i)}><SafeImg src={g} alt="" /></button>)}</div>
      <div className={"main-img zoom" + (zoom ? " on" : "")} onMouseEnter={() => setZoom(true)} onMouseLeave={() => setZoom(false)} onMouseMove={e => { const r = e.currentTarget.getBoundingClientRect(); setPos([(e.clientX - r.left) / r.width * 100, (e.clientY - r.top) / r.height * 100]) }}><SafeImg src={p.gallery[img]} alt={`${p.name}, image ${img + 1}`} style={{ transformOrigin: `${pos[0]}% ${pos[1]}%` }} /></div></div>
      <div className="buy"><h1>{p.name}</h1><RatingStars rating={p.rating} reviews={p.reviews} />
        <div className="price-row"><PriceDisplay price={p.price} originalPrice={p.originalPrice} />{d > 0 && <span className="badge static">Save {d}%</span>}</div>
        <p>{p.description}</p>
        <fieldset className="variants"><legend>Option: {variant}</legend>{p.variants.map(v => <button key={v} className={'chip' + (v === variant ? ' on' : '')} aria-pressed={v === variant} onClick={() => setVariant(v)}>{v}</button>)}</fieldset>
        <p className={'stock ' + (out ? 'out' : p.stock < 10 ? 'low' : '')}>{out ? 'Out of stock' : p.stock < 10 ? `Only ${p.stock} left` : 'In stock'}</p>
        <div className="row"><QuantitySelector value={qty} onChange={setQty} max={Math.max(max, 1)} />
          <button className="btn grow" disabled={out} onClick={add}>{added ? <><Check size={16} /> Added</> : out ? 'Unavailable' : 'Add to cart'}</button><WishlistButton product={p} /></div>
        {added && <p className="ok" role="status">Added to your cart. <Link to="/cart">View cart</Link></p>}
        <ul className="ship"><li><Truck size={16} /> Free shipping over ₹999</li><li><RotateCcw size={16} /> 30-day returns</li></ul>
        <div className="acc">{acc.map(([t, c], i) => <div key={t}><button aria-expanded={open === i} onClick={() => setOpen(open === i ? -1 : i)}>{t}<ChevronDown size={16} /></button>{open === i && <div className="acc-body">{c}</div>}</div>)}</div></div></div>
    <section className="sec"><h2>Customer reviews</h2><div className="rev"><div><p className="big-r">{p.rating}</p><RatingStars rating={p.rating} reviews={p.reviews} /></div>
      <div><div className="bars">{dist.map(([s, n]) => <div key={s}><span>{s}★</span><i><b style={{ width: n + '%' }} /></i><span>{n}%</span></div>)}</div>
      <blockquote>“Exactly as described, and it feels built to last.” <cite>Verified buyer</cite></blockquote></div></div></section>
    {rv.length > 0 && <section className="sec"><h2>Recently viewed</h2><ProductGrid items={rv} /></section>}
    <section className="sec"><h2>You may also like</h2><ProductGrid items={products.filter(x => x.category === p.category && x.id !== p.id).concat(products.filter(x => x.category !== p.category)).slice(0, 4)} /></section></div>
}
