// Policies live in the shared frontend file so the site and the assistant never disagree.
export { policies } from '../../../src/data/storePolicies.js'
