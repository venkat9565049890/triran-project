import 'dotenv/config'
import express from 'express'
import cors from 'cors'
import rateLimit from 'express-rate-limit'
import chat from './routes/chat.js'
const app = express()
app.use(cors({ origin: (process.env.FRONTEND_ORIGIN || 'http://localhost:5173').split(','), methods: ['POST', 'GET'] }))
app.use(express.json({ limit: '20kb' }))
app.get('/api/health', (_req, res) => res.json({ ok: true, aiConfigured: !!(process.env.ANTHROPIC_API_KEY && process.env.AI_MODEL) }))
app.use('/api/chat', rateLimit({ windowMs: 60_000, limit: 20, standardHeaders: true, legacyHeaders: false, message: { error: { code: 'rate_limited', message: 'Too many messages. Please wait a minute and try again.' } } }), chat)
app.use((e, _req, res, _next) => res.status(e.status === 400 || e.type === 'entity.parse.failed' ? 400 : 500).json({ error: { code: 'bad_request', message: 'Invalid request.' } }))
const port = process.env.PORT || 8787
app.listen(port, () => console.log(`Chat API on :${port}. AI configured: ${!!(process.env.ANTHROPIC_API_KEY && process.env.AI_MODEL)}`))
