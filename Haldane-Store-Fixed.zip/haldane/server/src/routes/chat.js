import { Router } from 'express'
import { askAI } from '../services/aiService.js'
import { products } from '../../../src/data/products.js'
const router = Router(), known = new Set(products.map(p => p.id))
const err = (res, status, code, message) => res.status(status).json({ error: { code, message } })
const ERRORS = { not_configured: [503, 'The AI assistant is not configured yet. Set ANTHROPIC_API_KEY and AI_MODEL in server/.env.'], timeout: [504, 'The AI assistant took too long to respond. Please try again.'], provider: [502, 'The AI service had a problem. Please try again shortly.'] }
router.post('/', async (req, res) => {
  const { message, history = [], productId } = req.body || {}
  if (typeof message !== 'string' || !message.trim()) return err(res, 400, 'invalid_message', 'Please type a message.')
  if (message.length > 500) return err(res, 400, 'message_too_long', 'Your message is too long (500 characters maximum).')
  if (!Array.isArray(history) || history.length > 20 || !history.every(h => h && ['user', 'assistant'].includes(h.role) && typeof h.content === 'string' && h.content.length <= 2000)) return err(res, 400, 'invalid_history', 'Invalid conversation history.')
  try { res.json(await askAI({ message: message.trim(), history: history.slice(-10), productId: known.has(Number(productId)) ? Number(productId) : null })) }
  catch (e) { const [s, m] = ERRORS[e.code] || [500, 'Something went wrong.']; if (!ERRORS[e.code]) console.error('chat error:', e.message); err(res, s, e.code || 'server_error', m) }
})
export default router
