# Haldane Store with AI chatbot

## 1. Requirements
Node.js 18 or newer (https://nodejs.org). Check with `node -v`.

## 2. Install (once)
```bash
cd haldane
npm run setup
```
This installs the website and the chat server, and creates `server/.env`.

## 3. Add your AI key
1. Create an API key in the Anthropic Console (https://console.anthropic.com).
2. Open `server/.env` and paste it:
```
ANTHROPIC_API_KEY=your-key-here
AI_MODEL=claude-sonnet-5-5
```
`AI_MODEL` can be any model name from Anthropic's current model list. Never put the key anywhere in `src/`.

## 4. Run everything
```bash
npm run dev:all
```
Open http://localhost:5173 and sign in with `demo` / `Haldane@123` (or press "Continue with demo account").
Click the green chat button at the bottom right.

Run separately instead (two terminals): `npm run dev` and `npm run server`.

## 5. Check it works
- http://localhost:8787/api/health shows `"aiConfigured": true` when the key is set.
- In the chat header, "Online" means the AI answered. "Catalog-only mode" means the server was unreachable or the key is missing; the note under the message says why.

## 6. Edit your store policies
`src/data/storePolicies.js`: replace every `[CONFIGURE ...]` value (delivery time, refunds, cancellation, payments, contact, tracking link). The assistant says "unavailable" until you do.

## 7. Deploy
- Website: `npm run build`, then upload `dist/` to any static host (links use `/#/` so refresh works).
- Chat API: host the `server/` folder on a Node host (Render, Railway, etc.), set `ANTHROPIC_API_KEY`, `AI_MODEL` and `FRONTEND_ORIGIN=https://your-site` there.
- Before building the website, set `VITE_API_URL=https://your-api-host` in a `.env` file in the project root (this is a URL, not a secret).

## Troubleshooting
- "Catalog-only mode": check `server/.env`, restart `npm run server`, and open /api/health.
- Port in use: stop other apps on 5173 or 8787, or change `PORT` in `server/.env`.
- "Too many messages": the server allows 20 messages a minute per visitor.

## Product photography (updated)
The storefront now uses real photography hosted by Unsplash instead of the drawn placeholder artwork. Product, category, and hero image URLs are defined in `src/data/products.js`.

- Product images: the `photos` map contains three photo references per product.
- Category images: `categoryImages` maps each category to a photo.
- Hero image: `heroImage` controls the homepage banner image.

An internet connection is required to load these hosted images. These are genuine stock photographs for visual presentation, **not verified photos of the exact products sold by a real supplier**. For an accurate production store, replace the URLs with your own product photos or images supplied by the manufacturer. You can still use the existing `npm run images` Pexels downloader if you prefer to download photos into `public/images/`; it requires a free Pexels API key.

## See the site on your phone
**Same Wi-Fi (quickest):** run `npm run dev:phone`, then on your phone open `http://YOUR-COMPUTER-IP:5173` (the terminal prints a "Network" address). If it doesn't load, allow Node through your computer's firewall.

**Anywhere, with a public link:** run `npm run build`, then drag the `dist` folder onto https://app.netlify.com/drop (or upload it to GitHub Pages, Vercel or any static host). The site works there as is. The AI chat needs the `server/` folder hosted separately (see Deploy); without it the chat runs in catalog-only mode.
