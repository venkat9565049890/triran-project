# Image photography notes

This project uses remotely hosted Unsplash photographs in `src/data/products.js`.

- `photos`: three image references per product ID.
- `categoryImages`: category card photos.
- `heroImage`: homepage hero photo.

The image URLs are requested from `images.unsplash.com` and are not stored as binary files in this ZIP, so an internet connection is required. They are real stock photographs, not product-authenticity claims or photos of a specific vendor's exact inventory. Before taking real orders, replace them with original product photos or approved supplier images and confirm the image rights/usage terms.
