// Downloads real photos from Pexels (free API key: https://www.pexels.com/api/) into public/images.
// Usage: PEXELS_API_KEY=your-key npm run images   (Windows PowerShell: $env:PEXELS_API_KEY="your-key"; npm run images)
// Results are keyword matches: review them and swap in your own product photos where they don't fit.
import fs from 'node:fs'
import path from 'node:path'
const key = process.env.PEXELS_API_KEY
if (!key) { console.error('Set PEXELS_API_KEY first (free at https://www.pexels.com/api/).'); process.exit(1) }
const products = ['brass table lamp desk', 'wooden monitor stand desk', 'felt desk mat workspace', 'brass tray desk', 'fountain pen', 'handmade paper notebook', 'pencil case roll', 'calligraphy ink bottles', 'canvas tote bag', 'laptop sleeve', 'aluminium laptop stand', 'leather cable organizer']
const jobs = [
  ...products.map((q, i) => ({ q, n: 3, files: [1, 2, 3].map(k => `products/${i + 1}-${k}.jpg`) })),
  ...[['desk', 'desk workspace lamp'], ['writing', 'writing stationery notebook'], ['carry', 'tote bag canvas'], ['tech', 'laptop stand workspace']].map(([id, q]) => ({ q, n: 1, files: [`categories/${id}.jpg`] })),
  { q: 'desk workspace lamp notebook', n: 1, files: ['hero.jpg'] },
]
const credits = []
for (const { q, n, files } of jobs) {
  try {
    const r = await fetch(`https://api.pexels.com/v1/search?query=${encodeURIComponent(q)}&per_page=${n}&orientation=portrait`, { headers: { Authorization: key } })
    if (!r.ok) throw new Error(`Pexels returned ${r.status}`)
    const { photos } = await r.json()
    for (let i = 0; i < files.length; i++) {
      const p = photos[i] || photos[0]; if (!p) { console.warn('No result for', q); continue }
      const img = await fetch(p.src.large); if (!img.ok) throw new Error(`Image download ${img.status}`)
      const file = path.join('public/images', files[i]); fs.mkdirSync(path.dirname(file), { recursive: true }); fs.writeFileSync(file, Buffer.from(await img.arrayBuffer()))
      credits.push(`${files[i]}: ${p.photographer} - ${p.url}`); console.log('saved', files[i])
    }
  } catch (e) { console.error(`Failed "${q}": ${e.message}`) }
  await new Promise(r => setTimeout(r, 400))
}
fs.writeFileSync('public/images/CREDITS.txt', 'Photos from Pexels (https://www.pexels.com)\n' + credits.join('\n') + '\n')
console.log('Done. Restart the dev server if it is running.')
